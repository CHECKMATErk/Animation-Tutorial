//
//  ViewController.swift
//  Test_App
//
//  Created by Rishik Kabra on 13/11/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var cardView: UIView!
    @IBOutlet weak var cardHeightConstraint: NSLayoutConstraint!
    
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var emojiSuperView: UIView!
    @IBOutlet weak var emojiImageView: UIImageView!
    @IBOutlet weak var imageTopConstraint: NSLayoutConstraint!
    
    var startY: CGFloat = 0.0
    var startTopConstraint: CGFloat = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.cardView.layer.cornerRadius = 12
        self.emojiImageView.layer.cornerRadius = self.emojiImageView.bounds.width/2
        self.emojiSuperView.layer.cornerRadius = self.emojiSuperView.bounds.width/2
        self.emojiSuperView.layer.borderColor = UIColor.white.cgColor
        self.emojiSuperView.layer.borderWidth = 2
        
        addPanGesture()
        self.statusLabel.isHidden = true
    }
    
    
    func addPanGesture(){
        let gesture = UIPanGestureRecognizer(target: self, action: #selector(recognizePanGesture(_:)))
        self.emojiImageView.addGestureRecognizer(gesture)
    }
    
    @objc func recognizePanGesture(_ recognizer: UIPanGestureRecognizer){
        guard let draggedView = recognizer.view else{
            return
        }
        
        if recognizer.state == .began {
            // When the drag is first recognized
            startY = draggedView.center.y
        }
        if recognizer.state == .ended{
            if draggedView.center.y < 575{
                draggedView.center.y = startY
                self.emojiImageView.center.y = startY
            }
        }
        
        if recognizer.state == .changed {
            let location = recognizer.location(in: self.view)
            let translation = recognizer.translation(in: self.view)
            //using only y value since only vertical position is needed
            if translation.y <= 0 && self.emojiImageView.isUserInteractionEnabled{
                print("upwards animation is not allowed, resetting your slider!")
                draggedView.center.y = startY
                recognizer.setTranslation(.zero, in: view)
            }
            else{
                if location.y < 600{
                    draggedView.center.y += translation.y
                    recognizer.setTranslation(.zero, in: view)
                }
                else{
                    //to ensure single API call
                    recognizer.state = .ended
                    self.view.bringSubviewToFront(self.emojiImageView)
                    
                    //change constraints(can be abstracted)
                    startTopConstraint = self.imageTopConstraint.constant
                    self.imageTopConstraint.constant = 600
                    draggedView.center.y = 600
                    self.emojiImageView.center.y = 600
                    
                    self.emojiImageView.isUserInteractionEnabled = false
                    recognizer.setTranslation(.zero, in: view)
                    
                    //Make API CALL
                    print("making api call")
                    
                    //Custom animation in the view, can be abstracted
                    self.emojiImageView.isHidden = true
                    UIView.animate(withDuration: 0.8, delay: 0, options: .curveLinear, animations: {
                        self.emojiSuperView.layer.backgroundColor = UIColor.green.cgColor
                    }, completion: nil)
                    UIView.animate(withDuration: 0.8, delay: 0, options: .curveLinear, animations: {
                        self.emojiSuperView.layer.backgroundColor = UIColor.yellow.cgColor
                    }, completion: nil)
                    UIView.animate(withDuration: 0.8, delay: 0, options: .curveLinear, animations: {
                        self.emojiSuperView.layer.backgroundColor = UIColor.red.cgColor
                    }, completion: nil)
                    UIView.animate(withDuration: 0.8, delay: 0, options: .curveLinear, animations: {
                        self.emojiSuperView.layer.backgroundColor = UIColor.blue.cgColor
                    }, completion: nil)
                    
                    //MARK: Network operations begin
                    // we can abstract this to a network layer and use closures, on success of the call can get the data
                    //Success Case: https://api.mocklets.com/p68348/success_case
                    //Failure Case: https://api.mocklets.com/p68348/failure_case
                    if let url = URL(string: "https://api.mocklets.com/p68348/success_case"){
                        var request = URLRequest(url: url)
                        request.httpMethod = "GET"
                        let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
                            guard let data = data else { return }
                            do{
                                let jsonresult = try JSONSerialization.jsonObject(with: data, options: [])
                                if let jsonDict = jsonresult as? NSDictionary{
                                    if let success = jsonDict.object(forKey: "success") as? Bool {
                                        if success{
                                            DispatchQueue.main.async {
                                                self.statusLabel.text = "Success!"
                                                self.statusLabel.isHidden = false
                                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                                    self.statusLabel.isHidden = true
                                                }
                                                //increasing card width
                                                UIView.animate(withDuration: 1, delay: 0.1, options: .transitionCurlDown, animations: {
                                                    self.cardHeightConstraint.constant = 450
                                                    self.view.layoutIfNeeded()
                                                }, completion: nil)
                                                //Changing ring to black
                                                UIView.animate(withDuration: 0.8, delay: 0, options: .curveLinear, animations: {
                                                    self.emojiSuperView.layer.backgroundColor = UIColor.black.cgColor
                                                }, completion: nil)
                                            }
                                        }
                                        else{
                                            //failure
                                            // don't expand card and send image back
                                            DispatchQueue.main.async {
                                                self.statusLabel.text = "Failure!"
                                                self.emojiImageView.image = UIImage.init(named: "sad")
                                                self.statusLabel.isHidden = false
                                                UIView.animate(withDuration: 0.8, delay: 0, options: .curveLinear, animations: {
                                                    self.emojiSuperView.layer.backgroundColor = UIColor.black.cgColor
                                                }, completion: nil)
                                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                                    self.statusLabel.isHidden = true
                                                }
                                                draggedView.center.y = self.startY
                                                self.emojiImageView.isUserInteractionEnabled = true
                                                self.emojiImageView.center.y = self.startY
                                                self.imageTopConstraint.constant = self.startTopConstraint
                                                self.emojiImageView.isHidden = false
                                            }
                                        }
                                    }
                                    else{
                                        print("Network call failed")
                                        DispatchQueue.main.async {
                                            draggedView.center.y = self.startY
                                            self.emojiImageView.isUserInteractionEnabled = true
                                            self.emojiImageView.center.y = self.startY
                                            self.imageTopConstraint.constant = self.startTopConstraint
                                            self.emojiImageView.isHidden = false
                                        }
                                    }
                                }
                            }
                            catch let error as NSError {
                                print(error.localizedDescription)
                            }
                        })
                        task.resume()
                    }
                }
            }
        }
    }
}

